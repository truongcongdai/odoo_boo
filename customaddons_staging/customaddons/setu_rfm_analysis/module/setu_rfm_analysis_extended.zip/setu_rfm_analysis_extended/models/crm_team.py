from odoo import fields, models, api
import json


class SalesTeam(models.Model):
    _inherit = 'crm.team'

    def _get_rfm_graph(self):
        team_id = self.id
        list_of_segment_revenue_dict = []
        segments = self.env['setu.rfm.segment'].sudo().search([('crm_team_id', '=', self.id)])
        query_exe = f"""
        SELECT
            seg.name as label,
            sum(data.total_revenue) as value
        FROM
            (
            select
                srs.id,
                coalesce(sum(so.amount_total),0) as total_revenue
            from
                setu_rfm_segment srs
                left join sale_order so on so.rfm_team_segment_id = srs.id
                where srs.crm_team_id = {team_id}
            group by
                srs.id
            UNION ALL
            
            select
                srs.id,
                coalesce(sum(po.amount_total),0) as total_revenue
            from
                setu_rfm_segment srs
                left join pos_order po on po.rfm_team_segment_id = srs.id
                where srs.crm_team_id = {team_id}
            group by
                srs.id
                
           
            )data inner join setu_rfm_segment seg on data.id = seg.id  
        GROUP BY
            seg.id,seg.name;
        
        """
        pos_q = """ UNION ALL
            
            select
                srs.id,
                coalesce(sum(po.amount_total),0) as total_revenue
            from
                setu_rfm_segment srs
                left join pos_order po on po.rfm_team_segment_id = srs.id
                where srs.crm_team_id = {team_id}
            group by
                srs.id"""
        self._cr.execute(query_exe)
        data_dict = self._cr.dictfetchall()
        return [
            {
                'values': data_dict,
                'area': True,
                'title': 'Segment Revenue',
                'key': 'Revenue Generated'
                # 'color': '#12F12F'
            }
        ]