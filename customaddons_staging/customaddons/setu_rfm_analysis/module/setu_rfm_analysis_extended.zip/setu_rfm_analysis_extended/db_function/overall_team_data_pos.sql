DROP FUNCTION if exists public.overall_team_data_pos(integer);
CREATE OR REPLACE FUNCTION public.overall_team_data_pos(IN sales_team_id integer)
RETURNS TABLE(
total_orders bigint,
total_revenue numeric
) AS
$BODY$
 BEGIN
 Return Query
 SELECT
    count(pso.*) as total_orders,
    sum(pso.amount_total) as total_revenue
 from
    pos_order pso
    left join pos_session ps on ps.id = pso.session_id
    left join pos_config pc on pc.id = ps.config_id
    where pso.rfm_team_segment_id is not null and
    pc.crm_team_id = sales_team_id;
END;
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;
