DROP FUNCTION if exists public.gather_sales_and_pos_data(integer[], date, date);
CREATE OR REPLACE FUNCTION public.gather_sales_and_pos_data(
IN company_ids integer[],
IN start_date date,
IN end_date date)
RETURNS void AS
$BODY$

BEGIN

Drop Table if exists sales_data;
CREATE TEMPORARY TABLE sales_data(
so_id integer,
pos_id integer,
team_id integer,
company_id integer,
partner_id integer,
date_order date,
amount_total_per_line numeric,
tax_amount numeric
);
Insert into sales_data
Select
    so.id as so_id,
    null::integer as pos_id,
    so.team_id,
    so.company_id,
    case when rp.parent_id is null then so.partner_id else rp.parent_id end as partner_id,
    so.date_order::date,
    sum(case when source.usage = 'internal'
        then (sml.qty_done * sol.price_unit) /CASE COALESCE(so.currency_rate, 0::numeric) WHEN 0 THEN 1.0 ELSE so.currency_rate END
    else (-1 *sml.qty_done * sol.price_unit) /CASE COALESCE(so.currency_rate, 0::numeric) WHEN 0 THEN 1.0 ELSE so.currency_rate END
    end) as amount_total_per_line,

    sum(case when tax.price_include != 'true' then
        case when source.usage = 'internal' then
            (sml.qty_done * sol.price_unit) /CASE COALESCE(so.currency_rate, 0::numeric) WHEN 0 THEN 1.0ELSE so.currency_rate END
            else (-1 *sml.qty_done * sol.price_unit) /CASE COALESCE(so.currency_rate, 0::numeric) WHEN 0 THEN 1.0 ELSE so.currency_rate
         END

        end else 0 end * (tax.amount /100)) as tax_amount
From
    stock_move move
    Inner Join stock_move_line sml on sml.move_id = move.id
    Inner Join sale_order_line sol on sol.id = move.sale_line_id
    left join account_tax_sale_order_line_rel tax_rel on sale_order_line_id = sol.id
    left join account_tax tax on tax.id = account_tax_id
    Inner join sale_order so on so.id = sol.order_id
    Inner Join stock_location source on source.id = move.location_id
    Inner Join stock_location dest on dest.id = move.location_dest_id
    Left Join stock_warehouse source_warehouse ON source.parent_path::text ~~ concat('%/', source_warehouse.view_location_id, '/%')
    Left Join stock_warehouse dest_warehouse ON dest.parent_path::text ~~ concat('%/', dest_warehouse.view_location_id, '/%')
    Inner join res_partner rp on rp.id = so.partner_id
    Inner join res_company rc on rc.id = so.company_id
where
     1 = case when start_date is null
     then case when DATE_PART('day', now()::timestamp - so.date_order::timestamp)::integer <= rc.take_sales_from_x_days::integer then 1 else 0 end
     else case when so.date_order >= start_date then 1 else 0 end
     end

     and so.date_order::date <= end_date

     and 1 = case when array_length(company_ids,1) >= 1 then
     case when so.company_id = ANY(company_ids) then 1 else 0 end
     else 1 end

     and move.state = 'done'
group by so.id,so.team_id,so.company_id,so.partner_id, rp.parent_id,so.date_order

UNION ALL

select
    null::integer as so_id,
    case when sum(pol.qty) > 0 then pso.id else null::integer end as pos_id,
    pc.crm_team_id as team_id,
    pso.company_id,

    case when rp.parent_id is null then pso.partner_id else rp.parent_id end as partner_id,
    case when sum(pol.qty) > 0 then pso.date_order else null::date end as date_order,

    sum(case when pt.type in ('product','consu','service')
        then
        case when pol.qty > 0
            then (pol.qty * ((100 - pol.discount) * pol.price_unit/100)) /CASE COALESCE(pso.currency_rate, 0::numeric) WHEN 0 THEN 1.0 ELSE pso.currency_rate END
            else (pol.qty * ((100 - pol.discount) * pol.price_unit/100)) /CASE COALESCE(pso.currency_rate, 0::numeric) WHEN 0 THEN 1.0 ELSE pso.currency_rate END
            end
        else 0

        END

    ) amount_total_per_line,

    coalesce(sum(
        case when tax.price_include != 'true'
        then
        case when pt.type in ('product','consu','service')
            then
            case when pol.qty > 0
            then
                (pol.qty * ((100 - pol.discount) * pol.price_unit/100)) /CASE COALESCE(pso.currency_rate, 0::numeric) WHEN 0 THEN 1.0 ELSE pso.currency_rate END
            else
                (pol.qty * ((100 - pol.discount) * pol.price_unit/100)) /CASE COALESCE(pso.currency_rate, 0::numeric) WHEN 0 THEN 1.0 ELSE pso.currency_rate END
            end
            else
            0
            end
        else
        0
        end * (tax.amount /100)),0) as tax_amount



from
    pos_order_line pol
    Inner join pos_order pso on pso.id = pol.order_id
    Inner join pos_session ps on ps.id = pso.session_id
    Inner join pos_config pc on pc.id = ps.config_id
    Inner Join product_product pro ON pol.product_id = pro.id
    Inner Join product_template pt ON pro.product_tmpl_id = pt.id
    left join account_tax_pos_order_line_rel tax_rel on pos_order_line_id = pol.id
    left join account_tax tax on tax.id = account_tax_id
    Inner join res_partner rp on rp.id = pso.partner_id

    WHERE
    1 = case when start_date is not null and end_date is not null then
     case when (pso.date_order::date >= start_date and pso.date_order::date <= end_date) then 1 else 0 end
    else 1 end
    and 1 = case when array_length(company_ids,1) >= 1 then
     case when pso.company_id = ANY(company_ids) then 1 else 0 end
    else 1 end and
    pso.state::text = ANY (ARRAY['paid'::character varying::text,'invoiced'::character varying::text, 'done'::character varying::text])
    and pso.state not in ('draft','cancel')
    and pso.partner_id is not null
    and pc.crm_team_id is not null
--                and pt.type in ('product','consu')
    and pso.write_date < (select now() - interval '1 hour')
    group by pso.id, pso.partner_id, rp.parent_id, pso.company_id, pc.crm_team_id, pso.date_order;

END;
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;
