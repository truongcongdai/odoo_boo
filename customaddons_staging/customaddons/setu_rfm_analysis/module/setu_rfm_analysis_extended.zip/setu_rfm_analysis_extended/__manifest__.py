# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'PoS Sales Inclusion In RFM Analysis',
    'version': '15.0',
    'price': 199,
    'currency': 'EUR',
    'category': 'sale',
    'summary': """	
		RFM Analysis - A powerful marketing strategy
        RFM analysis increases business sales. It enables personalized marketing, increases engagement, and allows you to create specific, relevant offers to the right groups of customers.        
        RFM analysis allows marketers to target specific clusters of customers with communications that are much more relevant for their particular behavior – and thus generate much higher rates of response, plus increased loyalty and customer lifetime value.

        eCommerce sales analysis with RFM technique
        RFM analysis is a data driven customer behavior segmentation technique. 
        RFM analysis increases eCommerce sales. It enables personalized marketing, increases engagement, and allows you to create specific, relevant offers to the right groups of customers.
        It helps eCommerce sellers, online stores, marketplaces to boost their sales
        Directly integrated with Email Marketing, Automated mailing list generation feature 
		""",
    'website': 'https://www.setuconsulting.com',
    'support': 'support@setuconsulting.com',
    'description': """
        RFM analysis is a data driven customer behavior segmentation technique.
        RFM stands for recency, frequency, and monetary value.
        RFM is a method used for analyzing customer value.
        As you can gauge, RFM analysis is a handy method to find your best customers, understand their behavior and then run targeted email / marketing campaigns to increase sales, satisfaction and customer lifetime value.

        RFM analysis increases eCommerce sales.
        It enables personalized marketing, increases engagement, and allows you to create specific, relevant offers to the right groups of customers.
        RFM analysis allows marketers to target specific clusters of customers with communications that are much more relevant for their particular behavior – and thus generate much higher rates of response, plus increased loyalty and customer lifetime value.

        RFM Analysis, our solution helps you to run targeted email / marketing campaigns to increase sales, satisfaction and customer lifetime value.
        With our solution you can easily bifurcate your customers by RFM segments which gives you a clear idea about your marketing strategy.  
    """,
    'author': 'Setu Consulting Services Pvt. Ltd.',
    'license': 'OPL-1',
    'sequence': 25,
    'depends': ['setu_rfm_analysis', 'point_of_sale'],
    'images': ['static/description/banner.gif'],
    'data': ['db_function/gather_sales_and_pos_data.sql',
             'db_function/overall_company_data_pos.sql',
             'db_function/overall_team_data_pos.sql',
             'db_function/compute_sp.sql',
             'view/rfm_segment.xml'],
    'application': True,
    'live_test_url': 'http://95.111.225.133:5929/web/login',
}
